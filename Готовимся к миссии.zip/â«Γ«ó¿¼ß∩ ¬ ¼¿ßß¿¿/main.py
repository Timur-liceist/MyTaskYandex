from flask import Flask, request

app = Flask(__name__)


@app.route("/")
def mars():
    return "Миссия Колонизация Марса"


@app.route("/index")
def index():
    return "И на Марсе будут яблони цвести!"


@app.route("/promotion")
def promotion():
    return "Человечество вырастает из детства.\n" \
           "Человечеству мала одна планета.\n" \
           "Мы сделаем обитаемыми безжизненные пока планеты.\n" \
           "И начнем с Марса!\n" \
           "Присоединяйся!"
    # return "dkjgf"


@app.route("/image_mars")
def image_mars():
    return f"""<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <h1>Жди нас, Марс</h1>
    <img src="static/img/img.png">
    <div>Вот она какая, красная планета.</div>

</head>

</html>"""


@app.route("/promotion_image")
def promotion_image():
    return f"""<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet"
          href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css"
          integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1"
          crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="static/css/style.css">
    <h1>Жди нас, Марс</h1>
    <img src="static/img/img.png">

</head>
<body>

<div class="alert alert-success" role="alert">
    Человечеству мала одна планета.
</div>
<div class="alert alert-secondary" role="alert">
    Мы сделаем обитаемыми безжизненные пока планеты.
</div>
<div class="alert alert-warning" role="alert">
    И начнём с Марса!
</div>
<div class="alert alert-danger" role="alert">
    Присоединяйтесь!
</div>
</body>
</html>"""


@app.route('/astronaut_selection', methods=['POST', 'GET'])
def form_for_astronauts():
    if request.method == 'GET':
        return f'''<!doctype html>
<html lang="ru">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet"
          href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css"
          integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1"
          crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="static/css/style.css"/>
    <title>Пример формы</title>
</head>
<body>
<h1 align="center">Анкета претендента</h1>
<h6 align="center">Анкета претендента</h6>
<div>
    <form class="login_form" method="post">
        <input class="form-control" id="usname" aria-describedby="usnameHelp" placeholder="Введите фамилию"
               name="usname">
        <input class="form-control" id="name" aria-describedby="nameHelp" placeholder="Введите имя" name="name">
        <label for="classSelect"></label>
        <input type="email" class="form-control" id="email" aria-describedby="emailHelp"
               placeholder="Введите адрес почты" name="email">
        <div class="form-group">
            <label for="classSelect">Какое у Вас образование?</label>
            <select class="form-control" id="classSelect" name="class">
                <option>Начальное</option>
                <option>Среднее</option>
                <option>Высшее</option>
            </select>
        </div>
        <label for="classSelect"></label>
        <label for="classSelect">Какие у Вас профессии?</label>
        <div class="form-group form-check">
            <input type="checkbox" class="form-check-input" name="ingener_isledovatel">
            <label class="form-check-label" for="acceptRules">Инженер-исследователь</label>
        </div>
        <div class="form-group form-check">
            <input type="checkbox" class="form-check-input" name="ingener_builder">
            <label class="form-check-label" for="acceptRules">Инженер-строитель</label>
        </div>
        <div class="form-group form-check">
            <input type="checkbox" class="form-check-input" name="pilot">
            <label class="form-check-label" for="acceptRules">Пилот</label>
        </div>
        <div class="form-group form-check">
            <input type="checkbox" class="form-check-input" name="meteorolog">
            <label class="form-check-label" for="acceptRules">Метеоролог</label>
        </div>
        <div class="form-group form-check">
            <input type="checkbox" class="form-check-input" name="ingener_for_live">
            <label class="form-check-label" for="acceptRules">Инженер по жизнеобеспечению</label>
        </div>
        <div class="form-group form-check">
            <input type="checkbox" class="form-check-input" name="ingener_radiation">
            <label class="form-check-label" for="acceptRules">Инженер по радиационной защите</label>
        </div>
        <div class="form-group form-check">
            <input type="checkbox" class="form-check-input" name="Doctor">
            <label class="form-check-label" for="acceptRules">Врач</label>
        </div>
        <div class="form-group form-check">
            <input type="checkbox" class="form-check-input" name="biolog">
            <label class="form-check-label" for="acceptRules">Экзобиолог</label>
        </div>
        <label for="classSelect"></label>
        <div class="form-group">
            <label for="form-check">Укажите пол</label>
            <div class="form-check">
                <input class="form-check-input" type="radio" name="sex" id="male" value="male" checked>
                <label class="form-check-label" for="male">
                    Мужской
                </label>
            </div>
            <div class="form-check">
                <input class="form-check-input" type="radio" name="sex" id="female" value="female">
                <label class="form-check-label" for="female">
                    Женский
                </label>
            </div>
        </div>
        <div class="form-group">
            <label for="about">Почему Вы хотите принять участие в миссии?</label>
            <textarea class="form-control" id="about" rows="3" name="about"></textarea>
        </div>
        <div class="form-group">
            <label for="photo">Приложите фотографию</label>
            <input type="file" class="form-control-file" id="photo" name="file">
        </div>
        <div class="form-group form-check">
            <input type="checkbox" class="form-check-input" id="acceptRules" name="accept">
            <label class="form-check-label" for="acceptRules">Готовы остаться на Марсе?</label>
        </div>
        <button type="submit" class="btn btn-primary">Записаться</button>
    </form>
</div>
</body>
</html>'''
    elif request.method == 'POST':
        return "Форма отправлена"
@app.route("/carousel")
def carousel():
    return f"""<!doctype html>
<html lang="ru">
<head>
    <!-- Required meta tags -->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <!-- Google fonts -->
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,700&display=swap" rel="stylesheet">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="css/custom.css">

    <title>Bootstrap. Basic carousel</title>
</head>
<body>
    <!-- Carousel in a container -->
<div class="container">
        <div id="carousel-basic" class="carousel slide" data-ride="carousel">
            <!-- Indicators -->
            <ol class="carousel-indicators">
                <li data-target="carousel-basic" data-slide-to="0" class="active"></li>
                <li data-target="carousel-basic" data-slide-to="1"></li>
                <li data-target="carousel-basic" data-slide-to="2"></li>
            </ol>

            <!-- Wrapper -->
            <div class="carousel-inner" role="listbox">
                <div class="carousel-item active">
                    <img src="static/img/peisag1.png" alt="" class="img-fluid">
                    <div class="carousel-caption">
                        <h2>Карусель</h2>
                        <p>это демонстрация возможностей компонента carousel</p>
                    </div>
                </div>
                <div class="carousel-item">
                    <img src="static/img/peisag2.png" alt="" class="img-fluid">
                </div>
                <div class="carousel-item">
                    <img src="static/img/peisag3.png" alt="" class="img-fluid">
                </div>
            </div>

            <!-- Controls -->
            <a class="carousel-control-prev" href="#carousel-basic" role="button" data-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="sr-only">Назад</span>
            </a>
            <a class="carousel-control-next" href="#carousel-basic" role="button" data-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="sr-only">Вперед</span>
             </a>
        </div>

        <!-- Content -->

    </div>

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
</body>
</html>"""

if __name__ == "__main__":
    app.run(port=8080, host="127.0.0.1")
